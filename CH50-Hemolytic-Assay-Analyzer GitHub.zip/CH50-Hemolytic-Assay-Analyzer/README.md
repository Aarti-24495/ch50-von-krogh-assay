# CH50 Hemolytic Assay Analyzer

A complete Python toolkit for analyzing classical complement CH50 hemolytic assays using the Von Krogh (Hill) equation.

## Features
- Calculate Percent Hemolysis from plate reader OD values.
- Estimate CH50 automatically.
- Generate publication-quality graphs.
- Export CSV reports.

## Folder Structure

See repository folders for data, scripts, outputs, figures and notebook.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python scripts/calculate_percent_lysis.py
python scripts/fit_von_krogh.py
python scripts/generate_report.py
```

## Author

Ranjan Verma
