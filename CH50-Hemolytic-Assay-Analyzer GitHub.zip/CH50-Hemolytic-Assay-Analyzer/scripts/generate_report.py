import pandas as pd

results=pd.read_csv('../output/CH50_results.csv')
with open('../output/report_summary.txt','w') as f:
    f.write('CH50 Hemolytic Assay Report\n')
    f.write(results.to_string(index=False))
print('Report generated.')
