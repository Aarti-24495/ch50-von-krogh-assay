import pandas as pd

BLANK=0.05
TOTAL_LYSIS=1.10

df=pd.read_csv('../data/sample_CH50_data.csv')
df['Percent_Lysis']=((df['OD']-BLANK)/(TOTAL_LYSIS-BLANK))*100
df.to_csv('../output/percent_lysis_results.csv',index=False)
print(df)
