import pandas as pd
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

def hill(x,ch50,h):
    return 100/(1+(ch50/x)**h)

df=pd.read_csv('../output/percent_lysis_results.csv')
x=df['Dilution'].values
y=df['Percent_Lysis'].values

popt,_=curve_fit(hill,x,y,p0=[80,2],maxfev=10000)
ch50,h=popt

xx=np.linspace(min(x),max(x),200)
yy=hill(xx,ch50,h)

plt.figure(figsize=(6,4))
plt.scatter(x,y,label='Observed')
plt.plot(xx,yy,label='Hill Fit')
plt.xlabel('Serum dilution')
plt.ylabel('% Hemolysis')
plt.legend()
plt.tight_layout()
plt.savefig('../output/CH50_curve.png',dpi=300)

pd.DataFrame({'CH50':[ch50],'Hill_Slope':[h]}).to_csv('../output/CH50_results.csv',index=False)
print(ch50,h)
